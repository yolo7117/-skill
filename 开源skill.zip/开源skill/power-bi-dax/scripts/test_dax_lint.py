#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Regression tests for dax_lint.py. Standard library only.

Run:  python test_dax_lint.py
"""

import unittest

from dax_lint import lint


def findings_by_rule(dax_text):
    result = lint(dax_text)
    out = {}
    for f in result:
        out.setdefault(f["rule"], []).append(f)
    return out


class LintTests(unittest.TestCase):
    def test_r001_division_operator(self):
        f = findings_by_rule("Sales YoY % = DIVIDE ( [Sales] - [PY], [PY] )\nRatio = [A] / [B]")
        self.assertIn("R001", f)
        self.assertEqual(f["R001"][0]["line"], 2)

    def test_r001_no_false_positive_on_divide(self):
        f = findings_by_rule("Ratio = DIVIDE ( [A], [B] )")
        self.assertNotIn("R001", f)

    def test_r001_ignores_comments(self):
        f = findings_by_rule("-- old: Ratio = [A] / [B]\nRatio = DIVIDE ( [A], [B] )")
        self.assertNotIn("R001", f)

    def test_r002_whole_table_filter(self):
        dax = "Red Sales =\nCALCULATE ( [Total Sales], FILTER ( Sales, RELATED ( Product[Color] ) = \"Red\" ) )"
        f = findings_by_rule(dax)
        self.assertIn("R002", f)

    def test_r002_accepts_column_predicate(self):
        dax = "Red Sales = CALCULATE ( [Total Sales], Product[Color] = \"Red\" )"
        f = findings_by_rule(dax)
        self.assertNotIn("R002", f)

    def test_r003_average_percentage(self):
        f = findings_by_rule("Avg Margin = AVERAGE ( Sales[Margin %] )")
        self.assertIn("R003", f)

    def test_r003_no_false_positive_on_plain_average(self):
        f = findings_by_rule("Avg Qty = AVERAGE ( Sales[Qty] )")
        self.assertNotIn("R003", f)

    def test_r004_hasonevalue_values(self):
        f = findings_by_rule("Sel Cat = IF ( HASONEVALUE ( Product[Category] ), VALUES ( Product[Category] ) )")
        self.assertIn("R004", f)

    def test_r005_measure_in_iterator(self):
        dax = "Bad Share =\nSUMX ( Sales, DIVIDE ( Sales[Amount], [Total Sales] ) )"
        f = findings_by_rule(dax)
        self.assertIn("R005", f)

    def test_r005_column_arithmetic_ok(self):
        dax = "Weighted Margin =\nSUMX ( Sales, Sales[Qty] * ( Sales[Price] - Sales[Cost] ) )"
        f = findings_by_rule(dax)
        self.assertNotIn("R005", f)

    def test_r006_iferror(self):
        f = findings_by_rule("Safe = IFERROR ( [A] / [B], 0 )")
        self.assertIn("R006", f)

    def test_r007_time_intel_without_date_table(self):
        dax = "Sales YTD = CALCULATE ( [Sales], DATESYTD ( Sales[OrderDate] ) )"
        f = findings_by_rule(dax)
        self.assertIn("R007", f)

    def test_r007_ok_with_date_table(self):
        dax = "Sales YTD = CALCULATE ( [Sales], DATESYTD ( 'Date'[Date] ) )"
        f = findings_by_rule(dax)
        self.assertNotIn("R007", f)

    def test_r008_aggregation_in_calculated_column(self):
        dax = "COLUMN Sales[TotalAmount] = SUM ( Sales[Amount] )"
        f = findings_by_rule(dax)
        self.assertIn("R008", f)

    def test_r008_table_column_shape(self):
        dax = "Sales[TotalAmount] = SUM ( Sales[Amount] )"
        f = findings_by_rule(dax)
        self.assertIn("R008", f)

    def test_r008_no_false_positive_on_measure_file(self):
        # Bare "Name = SUM(...)" in a .dax file is normally a measure list.
        f = findings_by_rule("Total Sales = SUM ( Sales[Amount] )")
        self.assertNotIn("R008", f)

    def test_r005_all_pattern_accepted(self):
        # RANKX over ALL(...) with a measure is the recommended pattern.
        dax = "Rank = RANKX ( ALL ( Product[Name] ), [Total Sales], , DESC, DENSE )"
        f = findings_by_rule(dax)
        self.assertNotIn("R005", f)

    def test_clean_file_has_zero_findings(self):
        dax = (
            "Total Sales = SUM ( Sales[Amount] )\n"
            "Sales YTD = CALCULATE ( [Total Sales], DATESYTD ( 'Date'[Date] ) )\n"
            "Sales PY = CALCULATE ( [Total Sales], SAMEPERIODLASTYEAR ( 'Date'[Date] ) )\n"
            "Sales YoY % = VAR C = [Total Sales] VAR P = [Sales PY] RETURN DIVIDE ( C - P, P )\n"
        )
        self.assertEqual(lint(dax), [])

    def test_json_payload_shape(self):
        import json

        result = lint("Ratio = [A] / [B]")
        payload = json.dumps(result)
        self.assertIn('"rule"', payload)
        self.assertIn('"line"', payload)


if __name__ == "__main__":
    unittest.main()
