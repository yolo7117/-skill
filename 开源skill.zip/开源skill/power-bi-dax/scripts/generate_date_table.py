#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""generate_date_table.py — emit a complete, markable Date-table DAX script.

Pure standard library. Produces a calculated table with Year, Quarter, Month,
Week, fiscal columns, sort keys, and working-day flags — everything the time
intelligence reference file assumes.

Usage:
    python generate_date_table.py --start-year 2020 --end-year 2035
    python generate_date_table.py --start-year 2020 --end-year 2035 \
        --fiscal-start-month 7 --month-names en --table-name Date
"""

import argparse
import sys

ZH_MONTHS = [
    "1月", "2月", "3月", "4月", "5月", "6月",
    "7月", "8月", "9月", "10月", "11月", "12月",
]
EN_MONTHS = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]


def build_dax(start_year, end_year, table_name, fiscal_start, month_names):
    months = ZH_MONTHS if month_names == "zh" else EN_MONTHS
    fy_month = lambda m: months[m - 1]  # noqa: E731

    dax = f"""// ============================================================
// Date table: '{table_name}'
// Range: {start_year}-01-01 .. {end_year}-12-31 (contiguous, complete years)
// Fiscal year starts month {fiscal_start}.
//
// AFTER PASTING (Modeling > New table):
//   1. Table tools > Mark as date table > choose [Date]
//   2. Set Sort by column:
//        MonthName       -> MonthNumber
//        MonthShortName  -> MonthNumber
//        QuarterName     -> QuarterNumber
//        YearMonth       -> YearMonthKey
//        FiscalYear      -> FiscalYearKey
//        FiscalMonth     -> FiscalMonthOfYear
//        FiscalQuarter   -> FiscalQuarterKey
//   3. Relationship: {table_name}[Date] 1-* Fact[OrderDate]
//      All time-intelligence filters go through '{table_name}'[Date].
//   4. File > Options > Data Load > turn OFF "Auto date/time".
// ============================================================

{table_name} =
VAR FirstDate = DATE({start_year}, 1, 1)
VAR LastDate  = DATE({end_year}, 12, 31)
VAR FiscalStart = {fiscal_start}
VAR Base =
    ADDCOLUMNS (
        CALENDAR ( FirstDate, LastDate ),
        "Year", YEAR ( [Date] ),
        "MonthNumber", MONTH ( [Date] ),
        "DayOfMonth", DAY ( [Date] ),
        "DayOfWeekNumber", WEEKDAY ( [Date], 2 ),  -- 1=Mon .. 7=Sun
        "YearMonthKey", YEAR ( [Date] ) * 100 + MONTH ( [Date] )
    )
VAR Enriched =
    ADDCOLUMNS (
        Base,
        "QuarterNumber", ROUNDUP ( [MonthNumber] / 6 * 2, 0 ),
        "MonthShortName", "{fy_month(1)}",
        "YearMonth", FORMAT ( [Date], "YYYY-MM" ),
        "IsWeekend", [DayOfWeekNumber] >= 6,
        -- Fiscal year: months >= FiscalStart belong to the NEXT labeled year
        "FiscalYearKey", IF ( [MonthNumber] >= FiscalStart, [Year] + 1, [Year] ),
        "FiscalMonthOfYear",
            MOD ( [MonthNumber] - FiscalStart + 12, 12 ) + 1
    )
VAR Named =
    ADDCOLUMNS (
        Enriched,
        "MonthName", FORMAT ( [Date], "MMMM" ),
        "QuarterName", "Q" & [QuarterNumber],
        "FiscalYear", "FY" & [FiscalYearKey],
        "FiscalQuarterKey", ROUNDUP ( [FiscalMonthOfYear] / 3, 0 ),
        "FiscalMonth", "{fy_month(1)}"
    )
VAR Final =
    ADDCOLUMNS (
        Named,
        "FiscalQuarter", "FQ" & [FiscalQuarterKey]
    )
RETURN
    Final
"""
    # Replace the placeholder month strings with a SWITCH on month number.
    zh_switch = "SWITCH ( [MonthNumber], " + ", ".join(
        "%d, \"%s\"" % (i + 1, m) for i, m in enumerate(months)
    ) + " )"
    dax = dax.replace('"MonthShortName", "%s"' % fy_month(1), '"MonthShortName", ' + zh_switch)
    dax = dax.replace('"FiscalMonth", "%s"' % fy_month(1), '"FiscalMonth", ' + zh_switch)
    return dax


def main(argv=None):
    p = argparse.ArgumentParser(description="Generate a markable Date-table DAX script")
    p.add_argument("--start-year", type=int, required=True)
    p.add_argument("--end-year", type=int, required=True)
    p.add_argument("--table-name", default="Date")
    p.add_argument("--fiscal-start-month", type=int, default=1, choices=range(1, 13))
    p.add_argument("--month-names", choices=("zh", "en"), default="zh",
                   help="Month short-name language used in SWITCH (default zh)")
    p.add_argument("--out", help="Write to file instead of stdout")
    args = p.parse_args(argv)

    if args.end_year < args.start_year:
        p.error("--end-year must be >= --start-year")

    dax = build_dax(args.start_year, args.end_year, args.table_name,
                    args.fiscal_start_month, args.month_names)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(dax)
        print("wrote %s" % args.out)
    else:
        sys.stdout.write(dax)
    return 0


if __name__ == "__main__":
    sys.exit(main())
