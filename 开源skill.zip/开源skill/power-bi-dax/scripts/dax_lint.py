#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""dax_lint.py — static checker for DAX measure files.

Catches the classic silent-wrong-number and slow-measure patterns from the
Power BI DAX skill's reference files. Pure standard library.

Usage:
    python dax_lint.py measures.dax                 # text report
    python dax_lint.py measures.dax --format json   # machine-readable
    cat measures.dax | python dax_lint.py -         # stdin

Exit codes: 0 = no findings, 1 = findings, 2 = usage/IO error.
"""

import argparse
import json
import re
import sys

# ---------------------------------------------------------------------------
# Rule definitions
#
# Each rule scans per logical line (DAX is newline-tolerant, so we scan the
# whole text but report a line number for the first offending line).
# ---------------------------------------------------------------------------

# Strip DAX comments (-- to end of line, // to end of line, /* */ blocks)
COMMENT_LINE_RE = re.compile(r"(--|//).*$")
BLOCK_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)


def strip_comments(text):
    text = BLOCK_COMMENT_RE.sub(" ", text)
    return "\n".join(COMMENT_LINE_RE.sub("", line) for line in text.splitlines())


def iter_lines(clean_text):
    """Yield (line_number, line) over comment-stripped text."""
    for i, line in enumerate(clean_text.splitlines(), start=1):
        yield i, line


RULES = []


def rule(rule_id, severity, title):
    def deco(fn):
        RULES.append(
            {
                "id": rule_id,
                "severity": severity,
                "title": title,
                "fn": fn,
            }
        )
        return fn

    return deco


# R001: raw division operator outside of comments -> divide-by-zero risk
@rule("R001", "warning", "Use DIVIDE() instead of the / operator")
def r001(text, ctx):
    findings = []
    for ln, line in iter_lines(ctx["clean"]):
        # '/ ' or ' /' with digits/paren on either side; exclude line-comment
        # prefixes already stripped. Avoid matching '*/' leftovers (none after strip).
        for m in re.finditer(r"[A-Za-z0-9_\)\]]\s*/\s*[A-Za-z0-9_\(\[\.]", line):
            findings.append((ln, line.strip()))
            break
    return findings


# R002: FILTER(<TableName>, ...) used as a CALCULATE filter — whole-table scan
@rule(
    "R002",
    "warning",
    "FILTER over a whole table inside CALCULATE forces formula-engine iteration; "
    "use a column predicate or KEEPFILTERS (dimension-table FILTER is acceptable when "
    "the predicate needs a measure)",
)
def r002(text, ctx):
    findings = []
    # FILTER ( 'Table Name' ,   or   FILTER ( TableName ,
    # First arg must be a bare table ref (no column bracket right after).
    pattern = re.compile(
        r"FILTER\s*\(\s*('?[A-Za-z0-9_ ]+'?)\s*(?:'?[A-Za-z0-9_ ]+'?)?\s*\[", re.IGNORECASE
    )
    # Simpler and precise: FILTER ( <table-ref> , where table-ref has no '['
    pattern = re.compile(r"FILTER\s*\(\s*([A-Za-z0-9_' ]+?)\s*,", re.IGNORECASE)
    for ln, line in iter_lines(ctx["clean"]):
        for m in pattern.finditer(line):
            first_arg = m.group(1).strip().strip("'")
            if "[" in first_arg:
                continue
            # If the first argument is actually an expression producing a table
            # (e.g., FILTER ( VALUES ( ... ) , ... )) skip: contains parens.
            if "(" in first_arg or ")" in first_arg:
                continue
            findings.append((ln, line.strip()))
            break
    return findings


# R003: averaging a percentage/ratio column
@rule(
    "R003",
    "warning",
    "Averaging a percentage/ratio column gives rows equal weight; compute the ratio "
    "as a weighted measure (DIVIDE of summed numerator and denominator)",
)
def r003(text, ctx):
    findings = []
    pattern = re.compile(
        r"AVERAGE(X)?\s*\(\s*'?[A-Za-z0-9_ ]+'?\s*\[[^\]]*(%|pct|percent|ratio|rate|margin)[^\]]*\]",
        re.IGNORECASE,
    )
    for ln, line in iter_lines(ctx["clean"]):
        if pattern.search(line):
            findings.append((ln, line.strip()))
    return findings


# R004: HASONEVALUE + VALUES legacy pattern
@rule("R004", "info", "Replace HASONEVALUE+VALUES with SELECTEDVALUE")
def r004(text, ctx):
    findings = []
    if re.search(r"HASONEVALUE\s*\(", ctx["clean"], re.IGNORECASE) and re.search(
        r"VALUES\s*\(", ctx["clean"], re.IGNORECASE
    ):
        for ln, line in iter_lines(ctx["clean"]):
            if re.search(r"HASONEVALUE\s*\(", line, re.IGNORECASE):
                findings.append((ln, line.strip()))
    return findings


# R005: measure reference inside an iterator over a table
@rule(
    "R005",
    "warning",
    "Measure reference inside an iterator triggers an implicit CALCULATE per row "
    "(context transition) — a performance defect on large fact tables. Use column "
    "arithmetic, or iterate over VALUES(Dim[Key]) / dimension tables",
)
def r005(text, ctx):
    findings = []
    # Find iterator calls, then look for [Measure] within the call's parentheses.
    iterator_names = (
        "SUMX",
        "AVERAGEX",
        "COUNTX",
        "COUNTAX",
        "MINX",
        "MAXX",
        "PRODUCTX",
        "CONCATENATEX",
        "RANKX",
    )
    for name in iterator_names:
        pattern = re.compile(r"\b" + name + r"\s*\(", re.IGNORECASE)
        for m in pattern.finditer(ctx["clean"]):
            # Extract the call body by paren matching.
            start = m.end() - 1
            depth = 0
            body = ""
            for i in range(start, len(ctx["clean"])):
                ch = ctx["clean"][i]
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                    if depth == 0:
                        body = ctx["clean"][start : i + 1]
                        break
            if not body:
                continue
            # Recommended patterns iterate over ALL()/VALUES()/ALLSELECTED()/
            # ALLEXCEPT() — dimension granularity, measures are acceptable there.
            first_comma = body.find(",")
            first_arg = body[1:first_comma] if first_comma > 0 else body
            if re.search(
                r"\b(ALL|VALUES|ALLSELECTED|ALLEXCEPT|DISTINCT|SUMMARIZE)\s*\(",
                first_arg,
                re.IGNORECASE,
            ):
                continue
            # Measure reference: [Name] that is not immediately a column ref.
            # Column refs look like Table[Col]; a bare [ ... ] is a measure.
            if re.search(r"(?<![A-Za-z0-9_'\]])\[[^\]]+\]", body):
                ln = ctx["clean"][: m.start()].count("\n") + 1
                src_line = ctx["clean"].splitlines()[ln - 1].strip()
                findings.append((ln, src_line))
    # Deduplicate by line.
    seen = set()
    out = []
    for ln, src in findings:
        if ln not in seen:
            seen.add(ln)
            out.append((ln, src))
    return out


# R006: IFERROR wrapping (hides bugs, extra engine pass)
@rule("R006", "info", "IFERROR hides real bugs and costs an extra engine pass; fix the math or use COALESCE")
def r006(text, ctx):
    findings = []
    for ln, line in iter_lines(ctx["clean"]):
        if re.search(r"IFERROR\s*\(", line, re.IGNORECASE):
            findings.append((ln, line.strip()))
    return findings


# R007: time-intelligence function without a 'Date'[Date] reference
@rule(
    "R007",
    "warning",
    "Time-intelligence function used without referencing 'Date'[Date] — time "
    "intelligence requires a marked, contiguous date table and must filter "
    "through its date column",
)
def r007(text, ctx):
    findings = []
    ti = re.compile(
        r"\b(DATESYTD|DATESQTD|DATESMTD|SAMEPERIODLASTYEAR|DATEADD|PARALLELPERIOD|"
        r"TOTALYTD|TOTALQTD|TOTALMTD|PREVIOUSMONTH|PREVIOUSQUARTER|PREVIOUSYEAR|"
        r"NEXTMONTH|NEXTQUARTER|NEXTYEAR|DATESBETWEEN|DATESINPERIOD)\s*\(",
        re.IGNORECASE,
    )
    has_ti = bool(ti.search(ctx["clean"]))
    has_date_ref = bool(re.search(r"'Date'\s*\[", ctx["clean"], re.IGNORECASE))
    if has_ti and not has_date_ref:
        for ln, line in iter_lines(ctx["clean"]):
            if ti.search(line):
                findings.append((ln, line.strip()))
                break
    return findings


# R008: aggregation inside a calculated column definition.
# Column definitions have no filter context, so every row shows the grand
# total. Only column-shaped LHS (Table[Col]) or an explicit COLUMN keyword
# is flagged — a bare "Name = SUM(...)" in a .dax file is normally a
# measure list and must not fire.
@rule(
    "R008",
    "warning",
    "Aggregation inside a calculated column: columns have no filter context, so "
    "every row shows the grand total; aggregations belong in measures",
)
def r008(text, ctx):
    findings = []
    pattern = re.compile(
        r"(?:\bCOLUMN\s+)?\b([A-Za-z][A-Za-z0-9_']*\[)?([A-Za-z][A-Za-z0-9_ ]*)\]?\s*=\s*"
        r"(SUM|AVERAGE|COUNT|COUNTROWS|DISTINCTCOUNT|SUMX|AVERAGEX)\s*\(",
        re.IGNORECASE,
    )
    for ln, line in iter_lines(ctx["clean"]):
        m = pattern.search(line)
        if not m:
            continue
        if m.group(0).strip().upper().startswith("COLUMN"):
            findings.append((ln, line.strip()))
            continue
        # Table[Col] = aggregation -> column definition shape
        if m.group(1):
            findings.append((ln, line.strip()))
    return findings


# ---------------------------------------------------------------------------

def lint(text):
    ctx = {"clean": strip_comments(text)}
    findings = []
    for r in RULES:
        for ln, src in r["fn"](text, ctx):
            findings.append(
                {
                    "rule": r["id"],
                    "severity": r["severity"],
                    "title": r["title"],
                    "line": ln,
                    "source": src,
                }
            )
    findings.sort(key=lambda f: (f["line"], f["rule"]))
    return findings


def format_text(findings, filename):
    if not findings:
        return "%s: OK — no findings." % filename
    lines = ["%s: %d finding(s)" % (filename, len(findings))]
    for f in findings:
        lines.append(
            "  line %4d  [%s/%s] %s\n           %s"
            % (f["line"], f["severity"], f["rule"], f["title"], f["source"])
        )
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(description="Static checker for DAX measure files")
    p.add_argument("file", help="DAX file to check, or '-' for stdin")
    p.add_argument("--format", choices=("text", "json"), default="text")
    args = p.parse_args(argv)

    if args.file == "-":
        text = sys.stdin.read()
        name = "<stdin>"
    else:
        try:
            with open(args.file, "r", encoding="utf-8-sig") as fh:
                text = fh.read()
        except OSError as exc:
            print("dax_lint: cannot read %s: %s" % (args.file, exc), file=sys.stderr)
            return 2
        name = args.file

    findings = lint(text)
    if args.format == "json":
        print(json.dumps({"file": name, "findings": findings}, ensure_ascii=False, indent=2))
    else:
        print(format_text(findings, name))
    return 1 if findings else 0


if __name__ == "__main__":
    sys.exit(main())
