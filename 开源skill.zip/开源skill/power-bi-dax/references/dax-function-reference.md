# DAX Function Reference (Core Set)

Syntax, semantics, and the trap for each function you will actually use. Grouped by job. "DEPRECATED" marks legacy patterns to replace on sight.

## Aggregation (simple)

| Function | Notes & traps |
|---|---|
| `SUM ( Col )` | Column only. The workhorse; compiles to a VertiPaq scan. |
| `AVERAGE ( Col )` | Ignores blanks, counts zeros. Averaging a percentage column is almost always wrong — see `common-mistakes.md`. |
| `MIN` / `MAX` | Work on columns **and** two scalars (`MAX ( 0, [Measure] )` idiom for floors). |
| `COUNT ( Col )` | Counts non-blank values of a column. |
| `COUNTROWS ( Table )` | Counts rows; prefer over `COUNT` for IDs. `COUNTROWS ( ALLSELECTED ( T ) )` for "% of selected". |
| `DISTINCTCOUNT ( Col )` | Expensive on high-cardinality columns; a red flag above ~1M distinct values. |
| `COUNTBLANK ( Col )` | Data-quality checks. |

## Iterators (X-functions)

| Function | Notes & traps |
|---|---|
| `SUMX ( Table, expr )` | Row context over Table; expr is column arithmetic or measure. Measure reference = implicit CALCULATE per row — fine on small tables, a defect on 10M+ rows. |
| `AVERAGEX ( Table, expr )` | The correct way to compute a weighted/derived average (e.g., average basket = `SUMX(amount)/DISTINCTCOUNT(order)`). |
| `RANKX ( Table, expr, [value], [order], [ties] )` | Default ties handling is `SKIP` (1,1,3). Use `DENSE` for 1,1,2. The classic all-blanks bug: ranking a measure against a table without matching context — wrap in `ALL` of the ranked table's key. See `common-mistakes.md`. |
| `MINX` / `MAXX` | Row-wise min/max across expressions or columns. |
| `COUNTX` / `COUNTAX` | Rare; prefer `COUNTROWS ( FILTER ( ... ) )` only when a predicate must run per row. |

## Filter modifiers & table functions

| Function | Notes & traps |
|---|---|
| `CALCULATE ( expr, f1, ... )` | The only context-transition gate. Filters evaluated in outer context, applied after. See `evaluation-context.md` §3. |
| `CALCULATETABLE` | Same, returns a table. |
| `FILTER ( Table, expr )` | Always returns a table; **row by row**. Use a boolean predicate in CALCULATE when possible. |
| `ALL` / `ALLSELECTED` / `ALLEXCEPT` / `REMOVEFILTERS` | See the modifier table in `evaluation-context.md` §4. |
| `KEEPFILTERS ( f )` | Intersect instead of overwrite; makes column predicates slicer-safe. |
| `USERELATIONSHIP ( A[Key], B[Key] )` | Activate inactive relationship. Use inside CALCULATE; both args are full column refs. |
| `CROSSFILTER ( A[Key], B[Key], BothDirection )` | Per-measure direction override; prefer over model-level bidirectional. |
| `VALUES ( Col )` | Distinct values **in current filter context**, including the total-row virtual blank. Returns 1 row × 1 col. |
| `DISTINCT ( Col )` | Like VALUES without the added-blank row. |
| `SELECTEDVALUE ( Col, [alt] )` | DEPRECATED pattern replaced: `IF ( HASONEVALUE ( C ), VALUES ( C ) )`. Returns alt (default BLANK) when 0 or 2+ values. |
| `HASONEVALUE ( Col )` / `ISFILTERED` / `ISINSCOPE` | ISINSCOPE is the right tool for "% of parent vs % of total" visual logic. |
| `ADDCOLUMNS ( Table, "Name", expr )` | Adds computed columns to a table in row context. |
| `SUMMARIZE` | Group-by. DEPRECATED for adding measures (returns wrong-context values); use `SUMMARIZE` for grouping + `ADDCOLUMNS` for measures, or plain `SUMMARIZECOLUMNS` in queries. |
| `TOPN ( n, Table, expr, order )` | "Top N others" pattern: `VAR TopN = TOPN(...)` `VAR Rest = EXCEPT ( ALL ( T ), TopN )`. |
| `UNION` / `EXCEPT` / `INTERSECT` | Set ops; column schemas must match by position. |
| `NATURALINNERJOIN` / `RELATEDTABLE` | RELATEDTABLE for one-to-many lookups from the one side; `RELATED` from the many side (calculated columns). |
| `TREATAS ( Table, Col1, Col2 )` | Apply a table as filters on other columns — the virtual-relationship tool; replaces many bidirectional relationships. |

## Time intelligence

All require a **marked, contiguous date table** — see `time-intelligence.md`. Column argument is always the date table's date column.

| Function | Returns |
|---|---|
| `DATESYTD ( d, [year_end] )` | Year-to-date dates; `DATESYTD ( d, "6-30" )` for June-ending fiscal years. |
| `DATESQTD` / `DATESMTD` | Quarter/month to date. |
| `SAMEPERIODLASTYEAR ( d )` | Parallel period one year back. |
| `DATEADD ( d, n, granularity )` | Shift by n days/months/quarters/years. Traps on partial periods (a filtered week shifts to a partial week). |
| `PARALLELPERIOD ( d, n, gran )` | Like DATEADD but returns **full** periods. |
| `TOTALYTD ( expr, d, [filter], [year_end] )` | Shorthand for `CALCULATE ( expr, DATESYTD ( d ) )`. |
| `DATESBETWEEN ( d, start, end )` | Inclusive fixed window. |
| `DATESINPERIOD ( d, start, n, gran )` | Rolling windows: `DATESINPERIOD ( d, MAX ( d ), -12, MONTH )` = trailing 12 months. |
| `PREVIOUSMONTH` / `PREVIOUSQUARTER` / `PREVIOUSYEAR` | Full previous period (not day-shifted). |
| `NEXTMONTH` / `NEXTQUARTER` / `NEXTYEAR` | Full next period. |
| `FIRSTDATE` / `LASTDATE ( d )` | One-row date table; `LASTDATE` = "as of" anchor for semi-additive measures. |
| `OPENINGBALANCE...` / `CLOSINGBALANCE...` | Semi-additive inventory/balance math; mostly replace with `CALCULATE ( [Balance], LASTDATE ( d ) )`. |
| `EDATE` / `EOMONTH` | Scalar date math, no date-table requirement. |

## Logical & info

| Function | Notes & traps |
|---|---|
| `IF ( cond, a, b )` | Strictly evaluated lazily per branch; no short-circuit performance concern in measures. |
| `IF.EAGER` | Only when you must force branch evaluation order (rare). |
| `SWITCH ( TRUE (), c1, r1, ... , default )` | The readable multi-branch form; prefer over nested IF. |
| `BLANK ()` / `ISBLANK` | Blank ≠ 0 in filters; `BLANK() + 5 = 5` but `BLANK() && TRUE` semantics differ from SQL NULL — do not import SQL NULL intuitions. |
| `COALESCE ( a, b, ... )` | First non-blank; replaces `IF ( ISBLANK ( a ), b, a )`. |
| `DIVIDE ( num, den, [alt] )` | Zero/blank denominator → alt (default BLANK), never an error. MANDATORY over `/`. |
| `HASONEVALUE` / `SELECTEDVALUE` | See above. |
| `ERROR` / `IFERROR` | IFERROR hides real bugs (and costs a second engine pass); fix the math instead. |
| `LOOKUPVALUE ( result, searchCol, value, ... )` | Row-context VLOOKUP without a relationship; expensive per row — prefer relationships. |
| `USERELATIONSHIP`, `USERNAME`, `SELECTEDMEASURE` | The last one is for calculation groups only. |

## Text & conversion (slice-label work)

`FORMAT ( v, fmt )` — locale-sensitive; fixed strings via `"0.0%"`, `"#,##0"`. `CONCATENATEX ( Table, expr, delimiter, orderBy )` — the "list selected items" pattern. `VALUE`, `INT`, `ROUND`, `DIVIDE` on text-numeric columns — cast at ETL, not in DAX, whenever possible.

## Syntax reminders that bite

1. Measure reference is always `[Measure Name]`; column is always `Table[Column]`. A naked `Name` is a variable or an error — never a column.
2. Single quotes around table names are required only when the name contains spaces or starts with a digit: `'Date'[Date]`.
3. `%` in `SWITCH ( TRUE (), ... )` conditions uses DAX comparison, and `TRUE ()` must be a function call, not a keyword.
4. Line breaks inside `CALCULATE` filter arguments are fine; a comma placed **before** the closing parenthesis of a nested FILTER is the most common paste error from DAX Studio.
