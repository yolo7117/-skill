# Evaluation Context: The Only Mental Model That Matters

Every DAX bug is a context bug. This file gives the precise model; the `common-mistakes.md` file catalogs what it looks like in practice.

## 1. The two contexts

**Filter context** — the set of filters active on the data model when a measure evaluates. Created by:
- Rows, columns, and slicers of a visual (each cell has its own)
- Report/page/drillthrough filters
- Explicit filter arguments inside `CALCULATE`

**Row context** — "the current row" while iterating a table. Created by:
- Calculated columns (one row at a time, over the whole table)
- Iterator functions: `SUMX`, `AVERAGEX`, `COUNTX`, `MINX`, `MAXX`, `RANKX`, `FILTER`, `ADDCOLUMNS`, `SELECTCOLUMNS`, `GENERATE*`

The critical asymmetry: row context does **not** filter the model. Inside `SUMX`, other tables are not filtered by the current row unless a context transition happens.

## 2. Context transition

`CALCULATE` (and only CALCULATE, plus the implicit one around measure references) converts the active row context into an equivalent filter context before evaluating its expression.

```dax
-- Inside SUMX ( Sales, ... ), per row:
SUMX ( Sales, [Total Sales] )   -- [Total Sales] is wrapped in an implicit CALCULATE
```

Consequences you must be able to predict:
- A measure referenced inside an iterator gets the current row as filter — correct, but one VertiPaq callback per row. On a 10M+ row fact table this is a performance defect (see `performance-vertipaq.md`).
- `SUM ( Sales[Amount] )` inside a calculated column sums the **entire** table (row context does not filter); `[Total Sales]` in the same place also sums the entire table — via context transition of a one-row filter, which happens to equal the same number only when the column is unique per row.

## 3. CALCULATE evaluation order — memorize this

`CALCULATE ( <expr>, <filter1>, <filter2>, ... )` evaluates in this exact order:

1. **Explicit filter arguments are evaluated in the original outer filter context** — a variable capturing a measure before CALCULATE sees the old context, a measure call inside a filter argument sees the old context.
2. Context transition (if a row context exists).
3. Filters are applied. If a filter already exists on the same column(s), the new filter **overwrites** it (unless `KEEPFILTERS` is present).
4. `<expr>` evaluates in the resulting context.

```dax
-- Classic trap: the filter argument [Total Sales] > 1000 is evaluated
-- BEFORE filters apply, i.e., against the grand total, not per slice.
Top Products =
CALCULATE ( [Total Sales], FILTER ( Product, [Total Sales] > 1000 ) )
```

Variables are constants: `VAR` inside a measure is evaluated **once, where declared**, and its value does not change when context later changes. Hoist outer-context values into variables before CALCULATE when you need "the value before the filter".

## 4. Filter modifiers cheat

| Modifier | Effect on existing filters on the target column(s) |
|---|---|
| `Product[Color] = "Red"` (boolean) | Overwrites. Cannot reference measures; single column only; compiles to a VertiPaq scan (fast). |
| `FILTER ( Table, <expr> )` | Overwrites filters on **every column of Table** referenced in the expr; formula-engine iteration per row (slow). |
| `ALL ( Table )` / `ALL ( Col )` | Removes filters — denominator that never moves. |
| `ALLEXCEPT ( Table, Col )` | Removes all but the listed columns. |
| `ALLSELECTED ( Col )` | Removes inner visual grouping filters, keeps slicers — moving denominator. |
| `KEEPFILTERS ( <filter> )` | Intersects with existing filter instead of overwriting. |
| `REMOVEFILTERS ( )` | Reads better than ALL for clearing; same semantics. |
| `USERELATIONSHIP ( a, b )` | Activates an inactive relationship for this calculation only. |
| `CROSSFILTER ( a, b, direction )` | Overrides relationship direction for this calculation. |

Boolean-filter limitation: `Product[Color] = "Red"` cannot compare against a measure or another column. The moment you need `Product[Price] > [Avg Price]`, you must use `FILTER` — write it over the **dimension** table, never the fact table:

```dax
Expensive Red Sales =
CALCULATE (
    [Total Sales],
    Product[Color] = "Red",                       -- simple predicate: fast
    FILTER ( Product, Product[Price] > [Avg Price] )  -- dimension-filtered: acceptable
)
```

## 5. Variable semantics (the four rules)

1. A `VAR` is evaluated **once**, at its declaration point, in the context active there.
2. Later context changes (CALCULATE inside RETURN) do not retroactively change the variable.
3. Same expression inlined twice is evaluated twice; once in a variable, once total. Variables are both clearer and faster.
4. `VAR` names shadow columns/measures — do not name a variable the same as a real table column.

```dax
-- Wrong: SalesPY evaluated per current year, so same as current year value
YoY Bad =
CALCULATE ( [Total Sales], SAMEPERIODLASTYEAR ( 'Date'[Date] ) ) / [Total Sales]

-- Right: capture before CALCULATE shifts context
YoY Good =
VAR Current = [Total Sales]
VAR Previous = CALCULATE ( [Total Sales], SAMEPERIODLASTYEAR ( 'Date'[Date] ) )
RETURN DIVIDE ( Current - Previous, Previous )
```

## 6. Expanded tables (advanced, but explains "impossible" bugs)

Every table in the model carries a hidden **expanded table**: itself plus the primary-key columns of all tables on the many side... and all tables chained through relationships. Filters propagate through expanded tables, which is why:

- A slicer on `Product[Category]` filters `Sales` rows through the relationship.
- `ALL ( Sales )` inside CALCULATE can unexpectedly remove filters that "came from" Product through the expanded table; `REMOVEFILTERS ( Product[Category] )` is surgical where `ALL ( Sales )` is not.
- Bidirectional relationships create ambiguous expanded tables and unpredictable filter paths — one more reason to avoid them (see `performance-vertipaq.md`).

When a filter "mysteriously" reaches a table you did not intend, draw the relationship chain and reason in expanded-table terms.

## 7. A 60-second debugging protocol

When a measure returns a wrong number:

1. **Cardinalities**: put the measure on a card (no slicers) — is the grand total right? If yes, the aggregation logic is fine and the bug is context interaction.
2. **Slice by one key**: add one dimension to a table visual, compare against source data for a single known value.
3. **Check context transition**: is the expression inside an iterator? Does it reference a measure?
4. **Check CALCULATE order**: is any filter argument referencing a measure? It evaluated in the outer context.
5. **Check variables**: is anything computed in the wrong context and captured?
6. Only then suspect the engine: run it in DAX Studio (see `performance-vertipaq.md`).
