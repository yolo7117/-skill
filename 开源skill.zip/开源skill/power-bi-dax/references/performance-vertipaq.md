# Performance: VertiPaq Engine and Diagnosis

## 1. The two engines

Every DAX query is served by two cooperating engines:

- **Storage engine (VertiPaq)**: columnar, compressed, multithreaded, does scans, group-bys, simple joins, simple aggregations. Emits **xmSQL** in DAX Studio. Fast. Parallel. This is where time should go.
- **Formula engine**: single-threaded (per query plan region), interprets the DAX plan, handles everything VertiPaq cannot: complex iterators, context transitions, ranking, most `EARLIER`/variable-heavy logic. Slow per row.

**Diagnosis rule**: FE (formula engine) share > ~50% of server time on an important measure = the measure forces row-by-row work; rewrite it. The fix is almost always "turn per-row logic into column arithmetic VertiPaq can scan".

## 2. Reading DAX Studio server timings

Workflow:
1. Power BI Desktop: View > Performance Analyzer > Start > refresh visuals > copy the slow visual's DAX query.
2. DAX Studio: paste, enable **Server Timings**, run.
3. Read the bottom panel: FE ms vs SE ms, SE queries (count), and the xmSQL emitted.

| Reading | Meaning | Action |
|---|---|---|
| SE 95%+ of time | VertiPaq-bound | Model size/cardinality issue, not formula |
| FE 50%+ | Row-by-row logic | Rewrite measure (see §4) |
| Many small SE queries (parallelism low) | Callbacks from FE | Reduce context transitions / iterators |
| One SE query, huge ms | Scan of a huge or poorly compressed table | Model-side fix (§3) |

Performance Analyzer adds client-side render time; a visual "slow in the report but fast in DAX Studio" is a rendering problem (too many marks, custom visuals), not DAX.

## 3. Model-side levers (biggest payoff first)

1. **Cardinality**: every column's distinct count is compressed into dictionaries. Split `DateTime` into `Date` + `Time` (time column at second granularity is usually droppable). Flag any column > ~1M distinct values.
2. **Integer keys**: surrogate integer keys beat strings on join speed and dictionary size. Replace `OrderID` strings; strip whitespace/case variance from category strings.
3. **Relationship hygiene**: single-direction, one-to-many, from dimension to fact. Bidirectional only with a written justification (and prefer `CROSSFILTER` per measure or `TREATAS` virtual relationships instead).
4. **Column pruning**: every column pays in refresh, memory, and scan. If no visual, measure, or relationship uses it, drop it (use DAX Studio's "View Metrics" / VertiPaq Analyzer to find unused columns and their % of model size).
5. **Disable auto date/time**: each datetime column otherwise silently gains a hidden built-in date hierarchy — one hidden date table per datetime column. This alone can double model size.
6. **Aggregations**: for >100M-row fact tables, user-defined aggregations (aggregate tables + aggregation awareness) let VertiPaq answer most visuals from a small in-memory table.

## 4. Formula rewrites (measure-side)

Pattern table — the left column is the defect, the right is the fix:

| Defect pattern | Rewrite |
|---|---|
| `CALCULATE ( [M], FILTER ( Sales, ... ) )` over a fact table | Column predicate: `CALCULATE ( [M], Product[Color] = "Red" )` or `KEEPFILTERS(...)`; dimension-table FILTER when a measure comparison is unavoidable |
| Measure reference inside `SUMX` over a big fact table | Column arithmetic inside the iterator: `SUMX ( Sales, Sales[Qty] * Sales[Price] )` |
| `IF ( ISBLANK ( ... ) )` / `IFERROR` wrapping aggregations | `COALESCE` / fix the math; IFERROR costs an extra pass and hides bugs |
| `DIVIDE` inside `SUMX` per row | Hoist: compute numerator and denominator as separate sums, one DIVIDE at the end |
| `HASONEVALUE + VALUES` | `SELECTEDVALUE` |
| `%` via averaged percentage columns | Ratio measures: `DIVIDE ( SUMX ( num ), SUMX ( den ) )` |
| `RANKX ( ALL ( T ), [M] )` recalculated per row of a big visual | Restrict ranked table with `TOPN`, or pre-rank in a calculated table |
| Deeply nested `FILTER ( FILTER ( ... ) )` | Single FILTER with `&&` predicates, or `CALCULATETABLE` with modifiers |
| `SUMMARIZE` adding measures | `SUMMARIZE` + `ADDCOLUMNS`, or `SUMMARIZECOLUMNS` |
| Variables recomputed in loops | Hoist `VAR` outside iterators; each usage is a constant |
| `SEARCH`/`FIND`/calculated string keys in measures | Compute at ETL; string ops are formula-engine only |

## 5. Context-transition cost, concretely

```dax
-- Per row of Sales: implicit CALCULATE around [Total Sales]
-- → one SE callback per row group → FE orchestration dominates
Bad  Revenue Share = SUMX ( Sales, DIVIDE ( Sales[Amount], [Total Sales] ) )

-- One scan: numerator and denominator both aggregate
Good Revenue Share =
VAR TotalAll = CALCULATE ( SUM ( Sales[Amount] ), ALLSELECTED ( Sales ) )
RETURN DIVIDE ( SUM ( Sales[Amount] ), TotalAll )
```

On a 10M-row table this is routinely a 100× difference. The general law: **iterators over fact tables may only contain column arithmetic**; measures go in iterators over dimension tables or small `VALUES(...)` tables.

## 6. Acceptance targets

| Item | Target |
|---|---|
| Any single visual | < 1 s render (Performance Analyzer) |
| Any visual > 3 s | Treated as a defect: documented DAX Studio split + rewrite |
| Important measures | FE share < ~50% of server time |
| Model | No auto date/time hierarchies; no unused columns > 5% of model size; no bidirectional relationships without written justification |
| Refresh | Materialized calculated columns justified per column (slicing/relationship need) |

## 7. Diagnostic write-up template (for the deliverable)

```
Measure: <name>
Symptom: <visual> renders in <n> s on <dataset size>
DAX Studio split (before): FE <x>% / SE <y>%, SE queries <n>
Cause: <context transition / whole-table FILTER / cardinality / ...>
Rewrite: <new DAX>
DAX Studio split (after): FE <x>% / SE <y>%
Result: <before> ms → <after> ms (<ratio>×)
```
