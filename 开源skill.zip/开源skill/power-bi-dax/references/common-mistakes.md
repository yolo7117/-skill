# Common Mistakes: The Silent Wrong-Number Catalog

Each entry: symptom → root cause → fix. These are the bugs users actually report. Read this when reviewing an existing report or when a number "looks wrong but the DAX looks right".

## 1. "The total doesn't equal the sum of the rows"

**Cause**: measures are not additive — the total cell re-evaluates the measure in a broader context, it does not sum the visual's rows.

Classic: `IF ( SELECTEDVALUE ( T[Cat] ) = "A", [M1], [M2] )` — the total row has no selected category, falls to `[M2]`, and looks absurd.

**Fix**: compute both branches in full context and combine additively, or use `SUMX ( VALUES ( T[Cat] ), <branch logic> )` so the total genuinely adds branches. Rule: any measure with `IF`/`SWITCH` on a visual axis must state what the total should do — and be tested at the total level.

## 2. Averaging a percentage column

**Symptom**: "Average margin" is implausibly high/low;Finance rejects the report.

**Cause**: `AVERAGE ( Sales[Margin %] )` (or the visual's implicit average) gives every **row** equal weight — a $10 sale counts as much as a $100,000 sale.

**Fix**: ratio as a measure, weighted by the true denominator:

```dax
Margin % = DIVIDE ( SUMX ( Sales, Sales[Qty] * ( Sales[Price] - Sales[Cost] ) ), [Total Sales] )
```

## 3. Time intelligence returns blanks / repeats one number

**Cause**: 90%+ of the time — the date table is not dedicated+marked+contiguous. See `time-intelligence.md` §1 for the failure-signature table. The remaining cases: filtering `Sales[OrderDate]` instead of `'Date'[Date]`, or auto date/time hierarchies still in use on visuals.

**Fix**: fix the model first (mark the table, extend the range, repoint visuals), only then touch the DAX.

## 4. CALCULATE overwrote a slicer the user applied

**Symptom**: a measure ignores the Color slicer, or shows "Red" data under every slicer value.

**Cause**: CALCULATE's filter argument **overwrites** existing filters on the same column. `CALCULATE ( [M], Product[Color] = "Red" )` defeats the user's slicer by design.

**Fix**: wrap in `KEEPFILTERS` when the measure should intersect with user filters: `CALCULATE ( [M], KEEPFILTERS ( Product[Color] = "Red" ) )`. Decide per measure: override (marketing-defined cuts) vs respect (user-facing ratios).

## 5. RANKX returns all 1s, all blanks, or 1,1,3 unexpectedly

| Symptom | Cause | Fix |
|---|---|---|
| Everything ranks 1 | The expression is evaluated per row without measure context: `RANKX ( T, [M] )` where [M] is constant in that context | `RANKX ( ALL ( T[Key] ), [M] )` — rank over all key values, letting context transition per key |
| All blanks | The ranked table's key doesn't intersect the visual's context | Match granularity: `RANKX ( ALL ( T ), [M], [M], DESC, DENSE )` with the visual keyed identically |
| Ties show 1,1,3 vs expected 1,1,2 | Default ties = SKIP | Add `DENSE` as the fifth argument |

## 6. Measure vs calculated column confusion

**Symptom**: model refresh got slow / file ballooned; or a "column" shows the same number everywhere; or a column shows the grand total repeated per row.

**Cause**: an aggregation was written as a calculated column (`Col = SUM ( Sales[Amount] )` — no filter context in calculated columns, so every row shows the grand total).

**Fix**: aggregations are measures. Calculated columns exist for: row-level slicing keys, relationship keys, and materialized complex row logic that cannot be expressed at ETL. Everything else is a measure or an ETL column.

## 7. The filter argument that evaluated "too early"

**Symptom**: `FILTER ( Product, [Total Sales] > 1000 )` keeps/filters products based on the **grand-total** ranking, not per current slice.

**Cause**: CALCULATE evaluates its filter arguments in the **outer** context, before applying filters.

**Fix**: if per-slice logic is needed, restructure: `FILTER ( Product, CALCULATE ( [Total Sales] ) > 1000 )` inside a `CALCULATETABLE` over the desired context, or compute the threshold as a variable in the outer context deliberately. State in a comment which semantics you chose.

## 8. Implicit measures and the format-string trap

**Symptom**: two "Sales" numbers disagree in the same report; or a measure shows 3 decimal places on one page.

**Cause**: dragging raw columns into visuals creates **implicit measures** with their own aggregation and format; they silently coexist with explicit measures.

**Fix**: explicit measures only; set "Discourage implicit measures" in the model settings; one format string per measure (not per visual).

## 9. DIVIDE vs `/` — and the blank≠zero display problem

`A / B` errors on zero denominator (breaking whole visuals); `DIVIDE` returns BLANK. But BLANK renders as an empty cell — users read it as "no data". Where zero is the truthful value: `DIVIDE ( num, den, 0 )`, used deliberately and documented. Never blanket-replace BLANK with 0 in percentages (0% and "n/a" are different facts).

## 10. ALL() removing more than expected (expanded tables)

**Symptom**: `CALCULATE ( [M], ALL ( Sales ) )` also cleared the Category slicer that lives on Product.

**Cause**: expanded tables — filters travel through relationships, and `ALL ( Sales )` removes filters reaching Sales through the chain.

**Fix**: be surgical: `REMOVEFILTERS ( Sales )` vs `REMOVEFILTERS ( Product[Category] )`. Draw the relationship chain before using bare `ALL ( Table )` in a measure that coexists with slicers.

## 11. Iterator + measure on a big table (the slow report)

**Symptom**: one visual takes 5-20 s; DAX Studio shows FE > 50%.

**Cause**: `SUMX ( Sales, [Some Measure] )` triggers a context transition per row — the classic hidden cost (see `performance-vertipaq.md` §5).

**Fix**: column arithmetic inside the iterator; measures only over `VALUES ( Dim[Key] )` or dimension tables.

## 12. Sort-by-column and MonthName ordering

**Symptom**: months sort alphabetically (Apr, Aug, Dec...) or YearMonth sorts 2025-10 before 2025-2.

**Cause**: text columns sort alphabetically unless a Sort-by column is set.

**Fix**: carry numeric sort keys in the date table (`MonthNumber`, `YearMonthNum = Year*100+Month`) and set Sort by column; generate these with `scripts/generate_date_table.py` rather than by hand.
